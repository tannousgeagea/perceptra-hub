# people_detection - v1.0-release
            ## Dataset Information
            - Format: YOLO
            - Created: 2025-11-07T23:51:19.891129
            - Total Images: 15
            - Train: 12
            - Validation: 1
            - Test: 2

            ## Classes (2)
            0: car
1: person

            ## Directory Structure
            ```
            dataset/
            ├── images/
            │   ├── train/
            │   ├── valid/
            │   └── test/
            ├── labels/
            │   ├── train/
            │   ├── valid/
            │   └── test/
            └── data.yaml
            ```

            ## Usage
            Load with YOLOv8:
            ```python
            from ultralytics import YOLO

            model = YOLO('yolov8n.pt')
            model.train(data='data.yaml', epochs=100)
            ```
        